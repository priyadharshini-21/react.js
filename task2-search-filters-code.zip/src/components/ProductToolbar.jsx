import React from "react";

export default function ProductToolbar({
  search,
  onSearchChange,
  category,
  onCategoryChange,
  sortBy,
  onSortChange,
  categories = [],
}) {
  return (
    <div className="product-toolbar">
      <label className="toolbar-search">
        <span className="sr-only">Search products</span>
        <input
          type="search"
          value={search}
          onChange={(event) => onSearchChange(event.target.value)}
          placeholder="Search products..."
        />
      </label>

      <label>
        <span className="sr-only">Filter by category</span>
        <select value={category} onChange={(event) => onCategoryChange(event.target.value)}>
          <option value="all">All categories</option>
          {categories.map((item) => (
            <option key={item} value={item}>{item}</option>
          ))}
        </select>
      </label>

      <label>
        <span className="sr-only">Sort products</span>
        <select value={sortBy} onChange={(event) => onSortChange(event.target.value)}>
          <option value="default">Sort: Default</option>
          <option value="price-low-high">Price: Low to high</option>
          <option value="price-high-low">Price: High to low</option>
          <option value="name-a-z">Name: A to Z</option>
          <option value="name-z-a">Name: Z to A</option>
        </select>
      </label>
    </div>
  );
}
