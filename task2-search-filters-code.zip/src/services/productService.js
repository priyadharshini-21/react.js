// Product filtering, searching, sorting and pagination service.
// Adapt the product fields below if your API uses different names.
export function filterProducts(products, options = {}) {
  const {
    search = "",
    category = "all",
    sortBy = "default",
    page = 1,
    limit = 8,
  } = options;

  const query = search.trim().toLowerCase();

  let result = [...products];

  if (query) {
    result = result.filter((product) =>
      [product.title, product.name, product.description, product.category]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(query))
    );
  }

  if (category !== "all") {
    result = result.filter(
      (product) => String(product.category).toLowerCase() === category.toLowerCase()
    );
  }

  const getPrice = (product) => Number(product.price ?? 0);
  switch (sortBy) {
    case "price-low-high":
      result.sort((a, b) => getPrice(a) - getPrice(b));
      break;
    case "price-high-low":
      result.sort((a, b) => getPrice(b) - getPrice(a));
      break;
    case "name-a-z":
      result.sort((a, b) =>
        String(a.title ?? a.name ?? "").localeCompare(String(b.title ?? b.name ?? ""))
      );
      break;
    case "name-z-a":
      result.sort((a, b) =>
        String(b.title ?? b.name ?? "").localeCompare(String(a.title ?? a.name ?? ""))
      );
      break;
    default:
      break;
  }

  const total = result.length;
  const totalPages = Math.max(1, Math.ceil(total / limit));
  const safePage = Math.min(Math.max(1, Number(page) || 1), totalPages);
  const start = (safePage - 1) * limit;

  return {
    products: result.slice(start, start + limit),
    total,
    page: safePage,
    limit,
    totalPages,
  };
}
