Task 2 starter files: search, category filter, sorting, pagination.

IMPORTANT:
These are reusable React components/service files, not a verified drop-in replacement for your repository.
Before uploading, inspect your existing Products page and product service:
- If `filterProducts()` already exists, modify that existing function rather than creating a duplicate.
- Connect ProductToolbar state to your actual Products page.
- Confirm actual product fields (e.g. title/name, category, price, image).
- Import the CSS file.
- Run `npm install` (if needed) and `npm run dev`, then test all controls.

Do not upload INTEGRATION_EXAMPLE.jsx as a page without adapting its imports and product data to your app.
