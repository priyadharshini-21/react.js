// Example integration inside your existing Products page.
// Replace `products` with the product array already loaded by your app.
// If your service already exports filterProducts(), use that service instead
// of duplicating the function in src/services/productService.js.

import React, { useMemo, useState } from "react";
import { filterProducts } from "./src/services/productService";
import ProductToolbar from "./src/components/ProductToolbar";
import Pagination from "./src/components/Pagination";
import "./src/styles/product-controls.css";

export default function ProductsPageExample({ products = [] }) {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [sortBy, setSortBy] = useState("default");
  const [page, setPage] = useState(1);

  const categories = useMemo(
    () => [...new Set(products.map((p) => p.category).filter(Boolean))].sort(),
    [products]
  );

  const result = useMemo(
    () => filterProducts(products, { search, category, sortBy, page, limit: 8 }),
    [products, search, category, sortBy, page]
  );

  const updateSearch = (value) => { setSearch(value); setPage(1); };
  const updateCategory = (value) => { setCategory(value); setPage(1); };
  const updateSort = (value) => { setSortBy(value); setPage(1); };

  return (
    <section>
      <ProductToolbar
        search={search}
        onSearchChange={updateSearch}
        category={category}
        onCategoryChange={updateCategory}
        sortBy={sortBy}
        onSortChange={updateSort}
        categories={categories}
      />

      <p>{result.total} products found</p>

      <div className="products-grid">
        {result.products.map((product) => (
          <article className="product-card" key={product.id}>
            <img src={product.image} alt={product.title ?? product.name ?? "Product"} />
            <h3>{product.title ?? product.name}</h3>
            <p>{product.category}</p>
            <strong>${Number(product.price ?? 0).toFixed(2)}</strong>
          </article>
        ))}
      </div>

      {result.total === 0 && <p>No products match your search.</p>}

      <Pagination page={result.page} totalPages={result.totalPages} onPageChange={setPage} />
    </section>
  );
}
